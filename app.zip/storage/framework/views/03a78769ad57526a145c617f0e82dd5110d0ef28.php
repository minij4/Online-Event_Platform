

<?php $__env->startSection('title', 'Login'); ?> 

<?php $__env->startSection('content'); ?>

<div class="container">
  <h2>Admin panel</h2>
  <form action="/" autocomplete="off">
    <div class="form-group">
      <label for="username">Username:</label>
      <input type="text" class="form-control" id="username" placeholder="Enter username" name="username" autocomplete="off">
    </div>
    <div class="form-group">
      <label for="pwd">Password:</label>
      <input type="password" class="form-control" id="pwd" placeholder="Enter password" name="pswd" autocomplete="off">
    </div>
    <button type="submit" class="btn btn-dark">Submit</button>
  </form>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\Laravel\app\resources\views/admin-login.blade.php ENDPATH**/ ?>