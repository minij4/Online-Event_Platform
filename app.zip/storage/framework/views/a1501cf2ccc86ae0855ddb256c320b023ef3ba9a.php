

<?php $__env->startSection('title', 'Deleting games'); ?>

<?php $__env->startSection('content1'); ?>
<h4 class="pb-5">Ištrinkite nereikalingus žaidimus</h4>
    <?php if(\Session::has('success')): ?>
        <div class="alert alert-success alert-dismissible fade show">
            <button type="button" class="close" data-dismiss="alert">&times;</button>
            <?php echo \Session::get('success'); ?>

        </div>
    <?php endif; ?>  
<h5>Renginiai</h5>
<form method="post" action="<?php echo e(route('event.delete')); ?>">
<?php echo csrf_field(); ?>
    <div class="row">
        <div class="column pl-1 pr-4" style="width:20%">
            <select class="form-control" name="event" data-parsley-required="true">
            <?php $__currentLoopData = $events; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
            {
                <option value="<?php echo e($row->id); ?>"><?php echo e($row->eventName); ?></option>
            }
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>
        <div class="column">
            <button type="submit" class="btn btn-dark ">Ištrinti</button>
        </div>
    </div>
</form>
<h5>Žaidimai</h5>
<form method="post" action="<?php echo e(route('game.delete')); ?>">
<?php echo csrf_field(); ?>
    <div class="row">
        <div class="column  pl-1 pr-4" style="width:20%">
            <select class="form-control" name="game" data-parsley-required="true">
                <?php $__currentLoopData = $games; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
                {
                    <option value="<?php echo e($row->id); ?>"><?php echo e($row->gameName); ?></option>
                }
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>  
        </div>
        <div class="column">
            <button type="submit" class="btn btn-dark ">Ištrinti</button>
        </div>
    </div>
</form>
<h5>Užduotys</h5>
<form method="post" action="<?php echo e(route('task.delete')); ?>">
    <?php echo csrf_field(); ?>
    <div class="row">
        <div class="column pl-1 pr-4" style="width:20%">
            <select class="form-control" name = "task" data-parsley-required="true">
                <?php $__currentLoopData = $tasks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
                {
                    <option value="<?php echo e($row->id); ?>"><?php echo e($row->question); ?></option>
                }
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>  
        </div>
        <div class="column">
            <button type="submit" class="btn btn-dark " >Ištrinti</button>
        </div>
    </div>
</form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('/loged/event', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Laravel\app\resources\views//loged/delete.blade.php ENDPATH**/ ?>