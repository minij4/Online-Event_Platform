

<?php $__env->startSection('title', 'Creating game'); ?>

<?php $__env->startSection('content1'); ?>
    <div class="pt-5">
            <?php if(\Session::has('success')): ?>
                <div class="alert alert-success alert-dismissible fade show">
                    <button type="button" class="close" data-dismiss="alert">&times;</button>
                    <?php echo \Session::get('success'); ?>

                </div>
            <?php endif; ?>    
            <form method="POST" action="<?php echo e(route('game.post')); ?>">
                <?php echo csrf_field(); ?>
                <div class="row pb-4">
                    <div class="col">
                        <p>Žaidimo pavadinimas</p>
                        <input type="text" class="form-control" placeholder="" name="gameName">            
                    </div>
                    <div class="col">
                        <p>Žaidimas priskiriamas renginiui</p>
                        <select class="form-control" name="eventName" id="eventName" data-parsley-required="true">
                            <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
                            {
                                <option value="<?php echo e($row->id); ?>"><?php echo e($row->eventName); ?></option>
                            }
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>           
                    </div>
                </div>
                <div class="row">
                    <div class="col">
                            <button type="submit" class="btn btn-dark ">Sukurti</button>
                    </div>
                </div> 
            </form>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('/loged/event', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\Laravel\app\resources\views//loged/createGame.blade.php ENDPATH**/ ?>