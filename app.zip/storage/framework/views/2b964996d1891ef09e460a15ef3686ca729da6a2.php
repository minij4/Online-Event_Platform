

<?php $__env->startSection('title', 'Login to game'); ?> 

<?php $__env->startSection('content'); ?>

<div class="container pt-5">
    <?php if(session('error')): ?>
      <div class="alert alert-danger alert-dismissible">
        <button type="button" class="close" data-dismiss="alert">&times;</button>
          <?php echo e(session('error')); ?>

      </div>
    <?php endif; ?>
    <form method="POST" action="<?php echo e(route('player.post')); ?>">
        <?php echo csrf_field(); ?>
        <div class="row">
            <div class="col-sm-4 pb-4">
                <input type="text" id="nickname" class="form-control" placeholder="Dalyvio vardas" name="nickname" autocomplete="off">
            </div>
            <div class="col-sm-1">
                <button type="submit" class="btn btn-dark ">Prisijungti</button>
            </div>
        </div>
    </form>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Laravel\app\resources\views//game.blade.php ENDPATH**/ ?>