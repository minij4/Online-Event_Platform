<select name="" id="">
    <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <option value=" <?php echo e($row->id); ?>"> <?php echo e($row->eventName); ?> </option>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</select><?php /**PATH D:\xampp\htdocs\Laravel\app\resources\views/test.blade.php ENDPATH**/ ?>