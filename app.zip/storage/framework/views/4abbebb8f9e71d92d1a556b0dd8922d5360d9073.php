

<?php $__env->startSection('title', 'Start creating an event'); ?>

<?php $__env->startSection('content'); ?>

<div class="container">
    <h2>Sukurkite savo renginio žaidimus</h2>
    <br>
    <!-- Nav tabs -->
    <ul class="nav nav-tabs">
        <li class="nav-item">
            <a class="nav-link" href="/loged/createEvent">Sukurti Renginį</a>
        </li>
        <li class="nav-item">
            <a class="nav-link" href="/loged/createGame">Sukurti Žaidimą</a>
        </li>
        <li class="nav-item">
            <a class="nav-link" href="/loged/createTask">Sukurti Užduotį</a>
        </li>
        <li class="nav-item">
            <a class="nav-link" href="/loged/edit">Redaguoti</a>
        </li>
        <li class="nav-item">
            <a class="nav-link" href="/loged/delete">Ištrinti</a>
        </li>
        <li class="nav-item">
            <a class="nav-link" href="/loged/startGame">Paleisti Žaidimą</a>
        </li>
    </ul>

    <!-- Tab panes -->
    <div class="tab-content pt-4 content">
        <?php echo $__env->yieldContent('content1'); ?>
    </div>

    <script src="<?php echo e(url('js/active.js')); ?>"></script>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('/loged/layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Laravel\app\resources\views//loged/event.blade.php ENDPATH**/ ?>