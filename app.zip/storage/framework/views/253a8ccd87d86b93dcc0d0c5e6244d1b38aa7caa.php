

<?php $__env->startSection('title', 'Login'); ?> 

<?php $__env->startSection('content'); ?>

<div class="container">
  <h2>Registracija</h2>
  <form action="<?php echo e(route('register.custom')); ?>" method="POST" autocomplete="off">
  <?php echo csrf_field(); ?>
    <div class="form-group">
        <label for="username">Prisijungimo vardas:</label>
        <input type="text" class="form-control" id="username" placeholder="" name="username" value="<?php echo e(old('username')); ?>" autocomplete="off">
        <?php if($errors->has('username')): ?>
            <span class="text-danger"><?php echo e($errors->first('username')); ?></span>
        <?php endif; ?>
    </div>
    <div class="form-group">
        <label for="email">Elektroninis paštas:</label>
        <input type="email" class="form-control" id="email" placeholder="" name="email" value="<?php echo e(old('email')); ?>" autocomplete="off">
        <?php if($errors->has('email')): ?>
            <span class="text-danger"><?php echo e($errors->first('email')); ?></span>
        <?php endif; ?>
    </div>
    <div class="form-group">
        <label for="password">Slaptažodis:</label>
        <input type="password" class="form-control" id="password" placeholder="" name="password" autocomplete="off">
        <?php if($errors->has('password')): ?>
            <span class="text-danger"><?php echo e($errors->first('password')); ?></span>
        <?php endif; ?>
    </div>
    <button type="submit" class="btn btn-dark">Pateikti</button>
  </form>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\Laravel\app\resources\views/registration.blade.php ENDPATH**/ ?>