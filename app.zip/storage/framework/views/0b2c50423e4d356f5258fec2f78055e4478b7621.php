<?php $__env->startSection('title', 'Home'); ?>

<?php $__env->startSection('content'); ?>
    <div class="container px-4 px-lg-5 my-5">
        <div class="text-center">
            <h1 class="display-3 fw-bolder">Online renginių platforma</h1>
            <a href="/game" style="font-size:2rem" class="lead fw-normal mb-0 ">Prisijungti į žaidimą</a>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Laravel\app\resources\views//welcome.blade.php ENDPATH**/ ?>