

<?php $__env->startSection('title', 'Creating Stage'); ?>

<?php $__env->startSection('content1'); ?>
    <div class="pt-5">
        <div class="row pb-4">
            <div class="col">
                    <p>Etapas priskiriamas renginiui</p>
                    <select name="cars" class="custom-select">
                        <option selected>Renginys</option>
                        <option value=""></option>
                    </select>            
            </div>
            <div class="col">
                <p>Etapo pavadinimas</p>
                <form>
                    <div class="row">
                    <div class="col">
                        <input type="text" class="form-control" placeholder="" name="eventName">
                    </div>
                    <div class="col">
                        <button type="submit" class="btn btn-dark">Sukurti</button>
                    </div>
                    </div>
                </form>           
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('/loged/event', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\Laravel\app\resources\views/loged/createStage.blade.php ENDPATH**/ ?>