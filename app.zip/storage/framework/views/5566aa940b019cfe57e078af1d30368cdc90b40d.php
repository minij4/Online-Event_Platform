

<?php $__env->startSection('title', 'Creating Event'); ?>

<?php $__env->startSection('content1'); ?>
    <div class="pt-5">
        <?php if(\Session::has('success')): ?>
            <div class="alert alert-success alert-dismissible fade show">
                <button type="button" class="close" data-dismiss="alert">&times;</button>
                <?php echo \Session::get('success'); ?>

            </div>
            <?php endif; ?>    
        <p>Renginio pavadinimas</p>
        <form method="POST" action="<?php echo e(route('event.post')); ?>" >
            <?php echo csrf_field(); ?>
            <div class="row">
                <div class="col">
                    <input type="text" id="eventName" class="form-control" placeholder="" name="eventName">
                </div>
                <div class="col">
                    <button type="submit" class="btn btn-dark ">Sukurti</button>
                </div>
            </div>
              
        </form>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('/loged/event', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\Laravel\app\resources\views/loged/createEvent.blade.php ENDPATH**/ ?>