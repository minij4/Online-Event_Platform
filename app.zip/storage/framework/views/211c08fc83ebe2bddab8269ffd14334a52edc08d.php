

<?php $__env->startSection('title', 'Creating tasks'); ?>

<?php $__env->startSection('content1'); ?>
    <h4>Pasirinkite užduotį</h4>
    <ul class="nav">
        <li class="nav-item sq">
            <a class="nav-link square" href="tasks/photoBlur">Blur Nuotrauka</a>
        </li>
        <li class="nav-item sq">
            <a class="nav-link square" href="tasks/photoMosaic">Nuotraukos Mozaika</a>
        </li>
        <li class="nav-item sq">
            <a class="nav-link square" href="tasks/photo">Nuotrauka</a>
        </li>
       
    </ul>
    <ul class="nav">
        <li class="nav-item sq">
            <a class="nav-link square" href="tasks/videoBlur">Blur Video</a>
        </li>
        <li class="nav-item sq">
            <a class="nav-link square" href="tasks/video">Video</a>
        </li>
        <li class="nav-item sq">
            <a class="nav-link square" href="tasks/audio">Audio</a>
        </li>
    </ul>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('/loged/event', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\Laravel\app\resources\views/loged/createTask.blade.php ENDPATH**/ ?>