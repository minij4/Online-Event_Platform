

<?php $__env->startSection('title', 'Start a game'); ?>

<?php $__env->startSection('content1'); ?>
    <h4>Paleisti žaidimą</h4>

    <div class="row pt-5">
        <div class="col">
            <div class="dropdown">
                <select class="form-control" name="gameId" id="gameId" data-parsley-required="true">
                    <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
                    {
                        <option value="<?php echo e($row->id); ?>"><?php echo e($row->eventName . ' — ' . $row->gameName); ?></option>
                    }
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>     
            </div>
        </div>
        <div class="col">
            <button style="width:100%" type="submit" class="btn btn-secondary">Pridėti</button>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('/loged/event', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\Laravel\app\resources\views/loged/startGame.blade.php ENDPATH**/ ?>