

<?php $__env->startSection('title', 'Login'); ?> 

<?php $__env->startSection('content'); ?>

<div class="container">
  <h2>Prisijungimo duomenys:</h2>
    <?php if(session('error')): ?>
      <div class="alert alert-danger alert-dismissible">
        <button type="button" class="close" data-dismiss="alert">&times;</button>
          <?php echo e(session('error')); ?>

      </div>
    <?php endif; ?>
  <form method="POST" action="<?php echo e(route('login.custom')); ?>" autocomplete="off">
    <?php echo csrf_field(); ?>
    <div class="form-group">
      <label for="username">Prisijungimo vardas arba elektroninis paštas:</label>
      <input type="username" class="form-control" id="username" placeholder="" name="username" value="<?php echo e(old('username')); ?>" autocomplete="off">
      <?php if($errors->has('username')): ?>
        <span class="text-danger"><?php echo e($errors->first('username')); ?></span>
      <?php endif; ?>
    </div>
    <div class="form-group">
      <label for="password">Slaptažodis:</label>
      <input type="password" class="form-control" id="password" placeholder="" name="password" autocomplete="off">
      <?php if($errors->has('password')): ?>
        <span class="text-danger"><?php echo e($errors->first('password')); ?></span>
      <?php endif; ?>
    </div>
    <button type="submit" class="btn btn-dark">Pateikti</button>
  </form>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\Laravel\app\resources\views/login.blade.php ENDPATH**/ ?>