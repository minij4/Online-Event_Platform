

<?php $__env->startSection('title', 'Start a game'); ?>

<?php $__env->startSection('content1'); ?>
    <h4>Paleisti žaidimą</h4>

    <?php if(\Session::has('success')): ?>
        <div class="alert alert-success alert-dismissible fade show">
            <button type="button" class="close" data-dismiss="alert">&times;</button>
            <?php echo \Session::get('success'); ?>

        </div>
    <?php endif; ?> 
    <?php if(\Session::has('error')): ?>
        <div class="alert alert-warning alert-dismissible fade show">
            <button type="button" class="close" data-dismiss="alert">&times;</button>
            <?php echo \Session::get('error'); ?>

        </div>
    <?php endif; ?>  
    <form method="POST" action="<?php echo e(route('start.post')); ?>">
        <?php echo csrf_field(); ?>
        <div class="row pt-5">
            <div class="col">
                <div class="dropdown">
                    <select class="form-control" name="gameId" id="gameId" data-parsley-required="true">
                        <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
                        {
                            <option value="<?php echo e($row->id); ?>">
                                <?php echo e($row->eventName . ' — ' . $row->stage . ' etapas '); ?>  
                                <?php echo e($row->status === 1 ? "| aktyvus" : ""); ?>

                            </option>
                        }
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>     
                </div>
            </div>
            <div class="col">
                <button type="submit" class="btn btn-dark">paleisti / sustabdyti</button>
            </div>         
        </div>
    </form>
<?php $__env->stopSection(); ?>




<?php echo $__env->make('/loged/event', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Laravel\app\resources\views//loged/startGame.blade.php ENDPATH**/ ?>