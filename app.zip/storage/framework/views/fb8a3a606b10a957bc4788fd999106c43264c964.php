

<?php $__env->startSection('title', 'Deleting games'); ?>

<?php $__env->startSection('content1'); ?>
    <h4>Ištrinti nereikalingus žaidimus</h4>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('/loged/event', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\Laravel\app\resources\views/loged/delete.blade.php ENDPATH**/ ?>