

<?php $__env->startSection('title', 'Creating Event'); ?>

<?php $__env->startSection('content1'); ?>
    <div class="pt-5">
        <?php if(\Session::has('success')): ?>
            <div class="alert alert-success alert-dismissible fade show">
                <button type="button" class="close" data-dismiss="alert">&times;</button>
                <?php echo \Session::get('success'); ?>

            </div>
        <?php endif; ?>  
        
        <form method="POST" action="<?php echo e(route('event.post')); ?>" >
            <?php echo csrf_field(); ?>
            <div class="row">
                <div class="col-sm-4">
                    <input type="text" id="eventName" class="form-control" placeholder="Renginio pavadinimas" name="eventName">
                </div>
                <div class="col-sm-1 mr-5">
                    <input class="form-control" style="width:100px;" type="number" id="stages" placeholder="etapai" name="stages" min="1" max="10">
                </div>
                <div class="col-sm-1">
                    <button type="submit" class="btn btn-dark ">Sukurti</button>
                </div>
            </div>
        </form>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('/loged/event', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Laravel\app\resources\views/loged/createEvent.blade.php ENDPATH**/ ?>