

<?php $__env->startSection('title', 'Video task'); ?>

<?php $__env->startSection('content1'); ?>
    <div class="">
        <div class="dropdown pb-3">
            <button type="button" class="btn btn-dark dropdown-toggle" data-toggle="dropdown">
                Užduotys</button>
            <div class="dropdown-menu">
                <a class="dropdown-item" href="photoBlur">Blur nuotrauka</a>
                <a class="dropdown-item" href="photoMosaic">Nuotraukos mozaika</a>
                <a class="dropdown-item" href="photo">Nuotrauka</a>
                <a class="dropdown-item" href="videoBlur">Blur video</a>
                <a class="dropdown-item" href="video">Video</a>
                <a class="dropdown-item" href="audio">Audio</a>
            </div>
        </div>
        <h4>Vaizdo įrašo užduotis</h4>
        <?php if(\Session::has('success')): ?>
                <div class="alert alert-success alert-dismissible fade show">
                    <button type="button" class="close" data-dismiss="alert">&times;</button>
                    <?php echo \Session::get('success'); ?>

                </div>
        <?php endif; ?> 
        <form method="POST" action="<?php echo e(route('task.post')); ?>" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <div class="row pt-3">
            <div class="col">
                    <div class="mb-6">
                        <input type="file" name="file" id="file">
                        <?php $__errorArgs = ['file'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><small class="text-red-500"><?php echo e($message); ?></small><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    
                    <p>Trukmė</p>
                    <input type="text" class="form-control" placeholder="" name="time">
                </div>
                <div class="col">
                    <p>Klausimas</p>
                    <input type="text" class="form-control" placeholder="" name="question">

                    <div class="input-group pt-3">
                        <div class="input-group-prepend">
                            <div class="input-group-text">
                            <input type="radio" name="answerRadioId" value="1"> 
                            </div>
                        </div>
                        <input type="text" name="answerInput1" class="form-control" placeholder="atsakymas">
                    </div>
                    <div class="input-group  pt-3">
                        <div class="input-group-prepend">
                            <div class="input-group-text">
                            <input type="radio" name="answerRadioId" value="2"> 
                            </div>
                        </div>
                        <input type="text" name="answerInput2" class="form-control" placeholder="atsakymas">
                    </div>
                    <div class="input-group pt-3">
                        <div class="input-group-prepend">
                            <div class="input-group-text">
                            <input type="radio" name="answerRadioId" value="3"> 
                            </div>
                        </div>
                        <input type="text" name="answerInput3" class="form-control" placeholder="atsakymas">
                    </div>
                    <div class="input-group pt-3">
                        <div class="input-group-prepend">
                            <div class="input-group-text">
                            <input type="radio" name="answerRadioId" value="4"> 
                            </div>
                        </div>
                        <input type="text" name="answerInput4" class="form-control" placeholder="atsakymas">
                    </div>
                    <div class="row pt-5">
                        <div class="col">
                            <div class="dropdown">
                                <select class="form-control" name="gameId" id="gameId" data-parsley-required="true">
                                    <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
                                    {
                                        <option value="<?php echo e($row->id); ?>"><?php echo e($row->eventName . ' — ' . $row->gameName); ?></option>
                                    }
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>     
                            </div>
                        </div>
                        <div class="col">
                            <button style="width:100%" type="submit" class="btn btn-secondary">Pridėti</button>
                        </div>
                    </div>        
                </div>
            </div>
        </form>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('/loged/event', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\Laravel\app\resources\views//loged/tasks/video.blade.php ENDPATH**/ ?>