@extends('/loged/layout')

@section('title', 'Home')

@section('content')
    <div class="container px-4 px-lg-5 my-5">
        <div class="text-center">
            <h1 class="display-3 fw-bolder">Sėkmingai prisijungėte</h1>
                <a href="" style="font-size:2rem" class="lead fw-normal mb-0 "></a>
            </div>                
    </div>
@endsection